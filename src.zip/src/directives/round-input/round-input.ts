import { Directive } from '@angular/core';


@Directive({
	selector: '[round-input]'
})
export class RoundInputDirective{
	
	constructor(
	) {
	}

	ngAfterViewInit(){

	}


}
