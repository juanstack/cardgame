/*
** This class contain all configurations variables, and will be used as global variable can be accessed from everywhere
*  Just import like this
*  import {Env} from '../../environments/environment';  
*/

//--------------------------------
        //CONFIGURATION VARS
//---------------------------------

export var baseUrl:any = 'http://dev.ttwa.com/';
export var apiUrl:any = 'api/v1/';
export var pageSpeed:any = 500;


//--------------------------------
      //LOGIN PAGE ENDPOINTS
//---------------------------------



