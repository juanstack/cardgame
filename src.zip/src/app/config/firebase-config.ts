// export const firebaseConfig = {
//     apiKey: "AIzaSyApA39dNETLNYR5CisDzUA3fMDXe1GO7NY",
//     authDomain: "fir-start-2ddd6.firebaseapp.com",
//     databaseURL: "https://fir-start-2ddd6.firebaseio.com",
//     projectId: "fir-start-2ddd6",
//     storageBucket: "fir-start-2ddd6.appspot.com",
//     messagingSenderId: "433711559497"
// }

export const firebaseConfig = {
    apiKey: "AIzaSyCBRWRqQju03uHq_heeinT3MHdSW2mE5LQ",
    authDomain: "taptapwin-22154.firebaseapp.com",
    databaseURL: "https://taptapwin-22154.firebaseio.com",
    projectId: "taptapwin-22154",
    storageBucket: "taptapwin-22154.appspot.com",
    messagingSenderId: "961546155199"
}