import { Component } from '@angular/core';



@Component({
	selector: '[home-navigation-header]',
	templateUrl: 'home-navigation-header.html'
})
export class HomeNavigationHeaderComponent {

	constructor() {
	}

}
