import { Component } from '@angular/core';


@Component({
	selector: '[squadup-request-content]',
	templateUrl: 'squadup-request-content.html'
})
export class SquadupRequestContentComponent {

	constructor() {
	}

}
