import { Component } from '@angular/core';


@Component({
  selector: '[stage-result-content]',
  templateUrl: 'stage-result-content.html'
})
export class StageResultContentComponent {

  constructor() {
  }

}
