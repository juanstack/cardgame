import { Component } from '@angular/core';

@Component({
	selector: 'ranking-content, [ranking-content]',
	templateUrl: 'ranking-content.html'
})
export class RankingContentComponent {


	constructor() {
	}

}
