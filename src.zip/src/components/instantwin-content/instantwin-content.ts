import { Component } from '@angular/core';

@Component({
	selector: 'instantwin-content, [instantwin-content]',
	templateUrl: 'instantwin-content.html'
})
export class InstantwinContentComponent {

	constructor() {
	}

}
