import { Component } from '@angular/core';

@Component({
	selector: 'daily-mission-content, [daily-mission-content]',
	templateUrl: 'daily-mission-content.html'
})
export class DailyMissionContentComponent {

	constructor() {
	}

}
