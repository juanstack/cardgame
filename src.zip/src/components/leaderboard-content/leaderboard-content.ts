import { Component } from '@angular/core';

@Component({
	selector: 'leaderboard-content,[leaderboard-content]',
	templateUrl: 'leaderboard-content.html'
})
export class LeaderboardContentComponent {

	constructor() {
	}

}
