import { Component } from '@angular/core';

@Component({
	selector: 'store-content, [store-content]',
	templateUrl: 'store-content.html'
})
export class StoreContentComponent {

	constructor() {

	}

}