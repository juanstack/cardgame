import { Component } from '@angular/core';

@Component({
	selector: 'instantwin-content-score-information',
	templateUrl: 'instantwin-content-score-information.html'
})
export class InstantwinContentScoreInformationComponent {

	constructor() {
	}

}