import { Component } from '@angular/core';

@Component({
	selector: '[winning-animation-second-screen-content]',
	templateUrl: 'winning-animation-second-screen-content.html'
})
export class WinningAnimationSecondScreenContentComponent {

	constructor() {}

}
