import { Component } from '@angular/core';


@Component({
	selector: '[achievement-content]',
	templateUrl: 'achievement-content.html'
})
export class AchievementContentComponent {

	constructor() {
	}

}
