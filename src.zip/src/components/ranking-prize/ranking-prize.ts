import { Component } from '@angular/core';


@Component({
	selector: 'ranking-prize',
	templateUrl: 'ranking-prize.html'
})

export class RankingPrizeComponent {

	constructor() {
	}

}
