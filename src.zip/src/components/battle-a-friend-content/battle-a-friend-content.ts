import { Component } from '@angular/core';

@Component({
	selector: '[battle-a-friend-content]',
	templateUrl: 'battle-a-friend-content.html'
})
export class BattleAFriendContentComponent {

	constructor() {
	}

}
