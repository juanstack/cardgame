import { Component } from '@angular/core';

@Component({
	selector: 'head2head-are-you-ready',
	templateUrl: 'head2head-are-you-ready.html'
})
export class Head2headAreYouReadyComponent {

	text: string;

	constructor() {
	}

}
