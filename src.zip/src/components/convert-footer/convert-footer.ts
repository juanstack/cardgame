import { Component } from '@angular/core';


@Component({
	selector: 'convert-footer',
	templateUrl: 'convert-footer.html'
})
export class ConvertFooterComponent {

	constructor() {
	}

}
